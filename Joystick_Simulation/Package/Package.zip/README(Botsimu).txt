Before starting to play your game, be sure to instal vjoy, which is located in FirstTimeSetup folder

1. Put PackageBotsimu.zip in the same directory as your game.
2. Extract PackageBotsimu.zip in the same directory as your game.
3. Run x360ce_x64.exe
4. The app should auto-detect your game, click on "Select a gmae to customize:", and select your game.
5. Start your game and get simulated.

Question:
- Is your game fully controller supported ? vjoy.py : keyboard.py
- If vjoy.py, which joystick is your walk/run? If else than a joystick, just use keyboard.py
- If vjoy.py, which button is your sprint?
- If keyboard, which key is your sprint and which key is walk/run ?
- If keyboard, is there a button for slow walking? If yes, what is it?